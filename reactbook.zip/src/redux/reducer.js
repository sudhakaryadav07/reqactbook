import { combineReducers } from 'redux';
import AuthReducer from '../reducer/reducer';

export default combineReducers({ AuthReducer });