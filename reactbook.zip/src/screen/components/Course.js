import React, { Component } from 'react';
import { Avatar, List, ListItem, ListItemText, ListItemSecondaryAction, IconButton, ListItemAvatar } from '@material-ui/core';
import { Delete } from '@material-ui/icons';
import { Image } from '@material-ui/icons';

class SkillSlider extends Component {

    handleOnChange = (e, value, item) => {
        this.props.handleSelectSkill(value, item)
    }

    render() {
        let { allCourses, recommendedCourses } = this.props.job;
        return (
            <div style={{ display: 'flex' }}>
                <List style={{ width: '80%', marginRight: 20, maxWidth: 360 }}>
                    {allCourses.sort((a, b) => { return b.rating - a.rating }).slice(0, 3).map((item, i) => {
                        return (
                            <ListItem key={i}>
                                <ListItemAvatar>
                                    <Avatar>
                                        <Image />
                                    </Avatar>
                                </ListItemAvatar>
                                <ListItemText primary={item.name} secondary={item.rating} />
                                <ListItemSecondaryAction>
                                    <IconButton edge="end" aria-label="delete" onClick={()=>this.props.handleDeleteCourse(item)}>
                                        <Delete />
                                    </IconButton>
                                </ListItemSecondaryAction>
                            </ListItem>
                        )
                    })}
                </List>
                <List style={{ width: '80%', maxWidth: 360 }}>
                    {recommendedCourses.sort().map((item, i) => {
                        return (
                            <ListItem key={i}>
                                <ListItemAvatar>
                                    <Avatar>
                                        <Image />
                                    </Avatar>
                                </ListItemAvatar>
                                <ListItemText primary={item.name} secondary={item.rating} />
                            </ListItem>
                        )
                    })}
                </List>
            </div >
        );
    }
}

export default SkillSlider;