

// export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';

// export const login = (data) => async (dispatch) => {
//     try {
//         dispatch({ type: LOGIN_SUCCESS, model: data });
//     } catch (e) {
//         console.log(e);
//     }
// }
